﻿using System;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Wizard wiz = new Wizard("Caster");
            Ninja nin = new Ninja("Sneaker");
            Samurai sam = new Samurai("Slasher");
        }
    }
}