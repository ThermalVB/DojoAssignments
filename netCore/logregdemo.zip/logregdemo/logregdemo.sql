SELECT `users`.`UserId`,
    `users`.`FirstName`,
    `users`.`LastName`,
    `users`.`Email`,
    `users`.`Password`,
    `users`.`CreatedAt`,
    `users`.`UpdatedAt`
FROM `logregdemo`.`users`;



