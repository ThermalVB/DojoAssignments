using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace passcode.Controllers
{
    public class HomeController : Controller
    {
        // GET: /Home/
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        [Route("/generate")]
        public string Generate()
        {
            Random rand = new Random();
            char[] dict = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9'};
            char[] reschars = new char[14];
            for(var i = 0; i<14; i++)
            {
                reschars[i] = dict[rand.Next(36)];
            }
            string resstring = new string(reschars);

            Console.WriteLine(resstring);

            return resstring;
        }
    }
}
