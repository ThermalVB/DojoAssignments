from django.shortcuts import render, redirect, HttpResponseRedirect
from .models import User, Quote
from django.contrib import messages
from django.contrib.auth import logout
import datetime

def index(request):
    return render(request, "exam/index.html")

def register(request):
    viewsResponse = User.objects.register(request.POST)
    if viewsResponse['isRegistered']:
        request.session['user_id'] = viewsResponse['user'].id
        request.session['name'] = viewsResponse['user'].name
        request.session['email'] = viewsResponse['user'].email
        request.session['date_of_birth'] = viewsResponse['user'].date_of_birth
        return redirect('exam:quotes')
    else:
        for error in viewsResponse['errors']:
            messages.error(request, error)
        return redirect('exam:index')

def quotes(request):
    user = request.session['user_id']
    context = {
    "my_quotes" : Quote.objects.filter(user = user),
    #|Quote.objects.filter(posted_by = user),
    "other_quotes" : Quote.objects.exclude(user = user)
    #.exclude(posted_by = user)
    }
    print context
    print Quote.objects.all()
    print User.objects.all()
    return render(request, 'exam/quotes.html', context)

def login(request):
    viewsResponse = User.objects.login_user(request.POST)
    print viewsResponse
    if viewsResponse['isLoggedIn']:
        request.session['user_id'] = viewsResponse['user'].id
        request.session['name'] = viewsResponse['user'].name
        return redirect('exam:quotes')

    else:
        for error in viewsResponse['errors']:
            messages.error(request, error)
        return redirect('exam:index')

def add_my_quote(request, id):
    print id

    user = User.objects.get(id = request.session['user_id'])
    quote = Quote.objects.get(id = id)
    print quote.user.count()
    quote.user.add(user)
    print quote.user.count()
    print "&" * 50
    return redirect('exam:quotes')

def remove_quote(request, id):
    print id
    print request.POST
    user = User.objects.get(id = request.session['user_id'])
    print user
    quote = Quote.objects.get(id = id)
    print quote
    quote.user.remove(user)
    return redirect('exam:quotes')

def add_quote(request):
    print "*" * 50
    print request.POST
    user = request.session['user_id']
    viewsResponse = Quote.objects.add_quote(request.POST, user)
    print viewsResponse
    print "&" * 50
    if viewsResponse['quoteExists']:
        print viewsResponse['quote'].quote_text
        print viewsResponse['quote'].posted_by
        print "quoteexists"
        return redirect('exam:quotes')
    else:
        print "got errors"
        for error in viewsResponse['errors']:
            messages.error(request, error)
        return redirect('exam:quotes')

def users(request, id):
    user = id
    print request.POST
    quotes = Quote.objects.filter(posted_by = user)
    print "*" * 50
    print quotes
    print "*" * 50
    context = {
    'quotes' : quotes,
    'user' : User.objects.get(id = id),
    'count' : Quote.objects.filter(posted_by = user).count()
    }
    print "*" * 50
    print context['quotes']
    print context['user']
    return render(request, 'exam/users.html', context)

def logout(request):
    request.session.clear()
    return redirect('exam:index')
